# Shop handler
execute as @a[scores={shop_iron_ingot=1..,token_storage=5..}] run function token:shop/iron_ingot
execute as @a[scores={shop_coal=1..,token_storage=5..}] run function token:shop/coal
execute as @a[scores={shop_bread=1..,token_storage=5..}] run function token:shop/bread
execute as @a[scores={shop_diamond=1..,token_storage=12..}] run function token:shop/diamond
execute as @a[scores={shop_ender_pearl=1..,token_storage=15..}] run function token:shop/ender_pearl
execute as @a[scores={shop_saddle=1..,token_storage=18..}] run function token:shop/saddle
execute as @a[scores={shop_name_tag=1..,token_storage=20..}] run function token:shop/name_tag
execute as @a[scores={shop_exp_bottle=1..,token_storage=25..}] run function token:shop/exp_bottle
execute as @a[scores={shop_diamond_pack=1..,token_storage=40..}] run function token:shop/diamond_pack
execute as @a[scores={shop_netherite_scrap=1..,token_storage=50..}] run function token:shop/netherite_scrap
execute as @a[scores={shop_blaze_rod=1..,token_storage=60..}] run function token:shop/blaze_rod
execute as @a[scores={shop_trident=1..,token_storage=75..}] run function token:shop/trident
execute as @a[scores={shop_elytra=1..,token_storage=100..}] run function token:shop/elytra
execute as @a[scores={shop_totem=1..,token_storage=75..}] run function token:shop/totem
execute as @a[scores={shop_shulker_shell=1..,token_storage=90..}] run function token:shop/shulker_shell
execute as @a[scores={shop_beacon=1..,token_storage=150..}] run function token:shop/beacon
execute as @a[scores={shop_shulker_box=1..,token_storage=140..}] run function token:shop/shulker_box
execute as @a[scores={shop_netherite_ingot=1..,token_storage=150..}] run function token:shop/netherite_ingot
execute as @a[scores={shop_elytra_upgraded=1..,token_storage=200..}] run function token:shop/elytra_upgraded
execute as @a[scores={shop_dragon_egg=1..,token_storage=300..}] run function token:shop/dragon_egg

# Balance
execute as @a[scores={balance=1..}] run function token:balance

# Playtime
execute as @a[scores={playtime=1..}] run function token:playtime/show
